package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Translate
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainTab
import com.example.ui.MainViewModel
import com.example.ui.components.PrivacyDialog
import com.example.ui.screens.DocumentExplainerScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TranslatorScreen
import com.example.ui.screens.VoiceAssistantScreen
import com.example.ui.screens.WritingAssistantScreen
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardElevated
import com.example.ui.theme.NavyDark
import com.example.ui.theme.PurpleGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPrimary

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                BolkarKaamApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun BolkarKaamApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val isEasyMode by viewModel.isEasyMode.collectAsStateWithLifecycle()
    val showPrivacyDialog by viewModel.showPrivacyDialog.collectAsStateWithLifecycle()
    val userFeedback by viewModel.userFeedbackMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    // Display feedback toasts/snackbars
    LaunchedEffect(userFeedback) {
        userFeedback?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearFeedbackMessage()
        }
    }

    // Predictive back handler: navigate back to ASSISTANT tab if on a sub-screen
    BackHandler(enabled = currentTab != MainTab.ASSISTANT) {
        viewModel.switchTab(MainTab.ASSISTANT)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyBackground),
        topBar = {
            BolkarKaamTopBar(
                isEasyMode = isEasyMode,
                currentTab = currentTab,
                onHistoryClick = { viewModel.switchTab(MainTab.HISTORY) },
                onEasyModeToggle = { viewModel.toggleEasyMode() }
            )
        },
        bottomBar = {
            BolkarKaamBottomBar(
                currentTab = currentTab,
                isEasyMode = isEasyMode,
                onTabSelect = { viewModel.switchTab(it) }
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(NavyBackground)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_animation"
            ) { tab ->
                when (tab) {
                    MainTab.ASSISTANT -> VoiceAssistantScreen(viewModel = viewModel)
                    MainTab.DOCS -> DocumentExplainerScreen(viewModel = viewModel)
                    MainTab.WRITER -> WritingAssistantScreen(viewModel = viewModel)
                    MainTab.TRANSLATE -> TranslatorScreen(viewModel = viewModel)
                    MainTab.HISTORY -> HistoryScreen(viewModel = viewModel)
                    MainTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }
            }
        }
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
        PrivacyDialog(
            onDismiss = { viewModel.setPrivacyDialogVisible(false) },
            onClearHistory = { viewModel.clearAllHistory() }
        )
    }
}

@Composable
fun BolkarKaamTopBar(
    isEasyMode: Boolean,
    currentTab: MainTab,
    onHistoryClick: () -> Unit,
    onEasyModeToggle: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(NavyDark)
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // App Branding with Neon Glow
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(VioletPrimary, CyanGlow)
                            )
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Bolkar Kaam Logo",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "बोलकर काम",
                            color = TextPrimary,
                            fontSize = if (isEasyMode) 20.sp else 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(VioletPrimary.copy(alpha = 0.25f))
                                .border(1.dp, VioletPrimary.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "AI",
                                color = CyanAccent,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                    Text(
                        text = "आपकी आवाज़, आपका डिजिटल सहायक",
                        color = TextSecondary,
                        fontSize = if (isEasyMode) 13.sp else 11.sp
                    )
                }
            }

            // Easy Mode quick chip & History Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Easy Mode Badge Button
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isEasyMode) CyanAccent else NavyCard)
                        .border(
                            1.dp,
                            if (isEasyMode) CyanGlow else Color(0xFF334155),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable(onClick = onEasyModeToggle)
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .testTag("topbar_easy_mode_toggle")
                ) {
                    Text(
                        text = if (isEasyMode) "आसान मोड: चालू" else "आसान मोड",
                        color = if (isEasyMode) Color.Black else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = if (isEasyMode) FontWeight.Bold else FontWeight.Normal
                    )
                }

                // History button
                IconButton(
                    onClick = onHistoryClick,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (currentTab == MainTab.HISTORY) VioletPrimary else NavyCard)
                        .testTag("topbar_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "बातचीत का इतिहास (Conversation History)",
                        tint = if (currentTab == MainTab.HISTORY) Color.White else TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun BolkarKaamBottomBar(
    currentTab: MainTab,
    isEasyMode: Boolean,
    onTabSelect: (MainTab) -> Unit
) {
    NavigationBar(
        containerColor = NavyDark,
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = Color(0xFF1E293B))
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        val navItems = listOf(
            NavItem(
                tab = MainTab.ASSISTANT,
                labelHi = "सहायक",
                selectedIcon = Icons.Filled.Mic,
                unselectedIcon = Icons.Outlined.Mic,
                tag = "nav_tab_assistant"
            ),
            NavItem(
                tab = MainTab.DOCS,
                labelHi = "दस्तावेज़",
                selectedIcon = Icons.Filled.Description,
                unselectedIcon = Icons.Outlined.Description,
                tag = "nav_tab_docs"
            ),
            NavItem(
                tab = MainTab.WRITER,
                labelHi = "लेखन",
                selectedIcon = Icons.Filled.Edit,
                unselectedIcon = Icons.Outlined.Edit,
                tag = "nav_tab_writer"
            ),
            NavItem(
                tab = MainTab.TRANSLATE,
                labelHi = "अनुवाद",
                selectedIcon = Icons.Filled.Translate,
                unselectedIcon = Icons.Outlined.Translate,
                tag = "nav_tab_translate"
            ),
            NavItem(
                tab = MainTab.HISTORY,
                labelHi = "इतिहास",
                selectedIcon = Icons.Filled.History,
                unselectedIcon = Icons.Outlined.History,
                tag = "nav_tab_history"
            ),
            NavItem(
                tab = MainTab.SETTINGS,
                labelHi = "सेटिंग्स",
                selectedIcon = Icons.Filled.Settings,
                unselectedIcon = Icons.Outlined.Settings,
                tag = "nav_tab_settings"
            )
        )

        navItems.forEach { item ->
            val isSelected = currentTab == item.tab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelect(item.tab) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.labelHi,
                        modifier = Modifier.size(if (isEasyMode) 26.dp else 22.dp)
                    )
                },
                label = {
                    Text(
                        text = item.labelHi,
                        fontSize = if (isEasyMode) 13.sp else 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    selectedTextColor = CyanAccent,
                    indicatorColor = VioletPrimary,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                ),
                modifier = Modifier.testTag(item.tag)
            )
        }
    }
}

private data class NavItem(
    val tab: MainTab,
    val labelHi: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
)
