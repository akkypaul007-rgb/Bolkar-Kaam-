package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiService
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationEntity
import com.example.data.local.ConversationRepository
import com.example.data.model.AppLanguage
import com.example.data.model.ChatMessage
import com.example.data.model.DocumentAnalysisResult
import com.example.data.model.MessageRole
import com.example.data.model.SpeechState
import com.example.data.model.WritingTemplate
import com.example.speech.VoiceManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class MainTab {
    ASSISTANT,
    DOCS,
    WRITER,
    TRANSLATE,
    HISTORY,
    SETTINGS
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "MainViewModel"
    }

    private val voiceManager = VoiceManager(application.applicationContext)
    private val geminiService = GeminiService()
    private val database = AppDatabase.getInstance(application.applicationContext)
    val repository = ConversationRepository(database.conversationDao())

    // Navigation & Global UI States
    private val _currentTab = MutableStateFlow(MainTab.ASSISTANT)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val _isEasyMode = MutableStateFlow(false)
    val isEasyMode: StateFlow<Boolean> = _isEasyMode.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(AppLanguage.HINDI)
    val selectedLanguage: StateFlow<AppLanguage> = _selectedLanguage.asStateFlow()

    private val _isAutoSpeakEnabled = MutableStateFlow(true)
    val isAutoSpeakEnabled: StateFlow<Boolean> = _isAutoSpeakEnabled.asStateFlow()

    // Voice & Speech Observables
    val speechState: StateFlow<SpeechState> = voiceManager.speechState
    val isSpeaking: StateFlow<Boolean> = voiceManager.isSpeaking
    val rmsVolume: StateFlow<Float> = voiceManager.rmsVolume

    // Active Conversation
    private val _currentConversationId = MutableStateFlow(UUID.randomUUID().toString())
    val currentConversationId: StateFlow<String> = _currentConversationId.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                role = MessageRole.ASSISTANT,
                text = "नमस्ते! मैं आपका डिजिटल सहायक 'बोलकर काम' हूँ।\nआप माइक बटन दबाकर बोलें या नीचे लिखें।\nजैसे: \"दवाइयों का समय याद दिलाओ\", \"2 दिन की छुट्टी का पत्र लिखो\" या \"बिजली बिल समझाओ\"।",
                quickActions = listOf("छुट्टी का आवेदन लिखो", "दस्तावेज़ समझाइए", "अंग्रेजी में अनुवाद करो")
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // Room Persistent History
    val conversationHistory: StateFlow<List<ConversationEntity>> = repository.allConversations
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Document Explainer State
    private val _selectedDocumentBitmap = MutableStateFlow<Bitmap?>(null)
    val selectedDocumentBitmap: StateFlow<Bitmap?> = _selectedDocumentBitmap.asStateFlow()

    private val _isAnalyzingDoc = MutableStateFlow(false)
    val isAnalyzingDoc: StateFlow<Boolean> = _isAnalyzingDoc.asStateFlow()

    private val _documentResult = MutableStateFlow<DocumentAnalysisResult?>(null)
    val documentResult: StateFlow<DocumentAnalysisResult?> = _documentResult.asStateFlow()

    // Writing Assistant State
    val writingTemplates = listOf(
        WritingTemplate(
            id = "leave_app",
            titleHi = "छुट्टी का आवेदन (Leave Application)",
            titleEn = "Leave Application",
            descriptionHi = "कंपनी या स्कूल के लिए बीमारी अथवा आवश्यक कार्य हेतु अवकाश पत्र",
            iconName = "email",
            category = "Leave Application",
            defaultPrompt = "मुझे 3 दिन की बीमारी की छुट्टी के लिए कार्यालय प्रबंधक को आवेदन पत्र लिखना है।",
            sampleInputs = listOf("2 दिन की शादी की छुट्टी", "अचानक अस्वस्थता हेतु छुट्टी", "परीक्षा के लिए 5 दिन की छुट्टी")
        ),
        WritingTemplate(
            id = "resume",
            titleHi = "बायोडाटा / रिज़्यूमे (Bio-Data)",
            titleEn = "Resume / Bio-Data",
            descriptionHi = "नौकरी या इंटरव्यू के लिए औपचारिक बायोडाटा प्रारूप",
            iconName = "person",
            category = "Resume / Bio-Data",
            defaultPrompt = "12वीं पास और कंप्यूटर ऑपरेटर पद के लिए एक सरल व प्रभावी बायोडाटा बनाएं।",
            sampleInputs = listOf("ड्राइवर पद के लिए बायोडाटा", "दुकान सहायक पद के लिए", "ऑफिस बॉय पद के लिए")
        ),
        WritingTemplate(
            id = "gov_complaint",
            titleHi = "सरकारी शिकायत / प्रार्थना पत्र",
            titleEn = "Official Complaint Letter",
            descriptionHi = "नगर निगम, बिजली बोर्ड या पुलिस स्टेशन के लिए औपचारिक पत्र",
            iconName = "gavel",
            category = "Official Complaint",
            defaultPrompt = "हमारे मोहल्ले में स्ट्रीट लाइट खराब होने की शिकायत नगर निगम अधिकारी को लिखनी है।",
            sampleInputs = listOf("पानी की समस्या हेतु पत्र", "राशन कार्ड में सुधार हेतु", "बिजली मीटर जांच हेतु")
        ),
        WritingTemplate(
            id = "shop_msg",
            titleHi = "व्यापार व ग्राहक संदेश (Business Message)",
            titleEn = "Business / Shop Message",
            descriptionHi = "दुकान के नए ऑफर्स या ग्राहकों को ऑर्डर डिलीवरी की जानकारी",
            iconName = "store",
            category = "Business Message",
            defaultPrompt = "दिवाली ऑफर के तहत कपड़ों पर 20% छूट का आकर्षक व्हाट्सएप संदेश लिखें।",
            sampleInputs = listOf("उधारी भुगतान स्मरण संदेश", "नया स्टॉक आने की सूचना", "त्योहार की बधाई व ऑफर")
        )
    )

    private val _selectedTemplate = MutableStateFlow<WritingTemplate?>(writingTemplates[0])
    val selectedTemplate: StateFlow<WritingTemplate?> = _selectedTemplate.asStateFlow()

    private val _writerCustomPrompt = MutableStateFlow(writingTemplates[0].defaultPrompt)
    val writerCustomPrompt: StateFlow<String> = _writerCustomPrompt.asStateFlow()

    private val _generatedDraft = MutableStateFlow<String?>(null)
    val generatedDraft: StateFlow<String?> = _generatedDraft.asStateFlow()

    private val _isGeneratingDraft = MutableStateFlow(false)
    val isGeneratingDraft: StateFlow<Boolean> = _isGeneratingDraft.asStateFlow()

    // Translator State
    private val _translatorInput = MutableStateFlow("")
    val translatorInput: StateFlow<String> = _translatorInput.asStateFlow()

    private val _translatorOutput = MutableStateFlow("")
    val translatorOutput: StateFlow<String> = _translatorOutput.asStateFlow()

    private val _sourceLang = MutableStateFlow("Hindi")
    val sourceLang: StateFlow<String> = _sourceLang.asStateFlow()

    private val _targetLang = MutableStateFlow("English")
    val targetLang: StateFlow<String> = _targetLang.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    // UI Dialogs
    private val _showPrivacyDialog = MutableStateFlow(false)
    val showPrivacyDialog: StateFlow<Boolean> = _showPrivacyDialog.asStateFlow()

    // Status message for feedback
    private val _userFeedbackMessage = MutableStateFlow<String?>(null)
    val userFeedbackMessage: StateFlow<String?> = _userFeedbackMessage.asStateFlow()

    fun switchTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun toggleEasyMode() {
        _isEasyMode.value = !_isEasyMode.value
    }

    fun setLanguage(lang: AppLanguage) {
        _selectedLanguage.value = lang
    }

    fun toggleAutoSpeak() {
        _isAutoSpeakEnabled.value = !_isAutoSpeakEnabled.value
    }

    fun setPrivacyDialogVisible(visible: Boolean) {
        _showPrivacyDialog.value = visible
    }

    fun clearFeedbackMessage() {
        _userFeedbackMessage.value = null
    }

    // Voice Controls
    fun startVoiceInput() {
        voiceManager.startListening(_selectedLanguage.value)
    }

    fun stopVoiceInput() {
        voiceManager.stopListening()
    }

    fun speakText(text: String) {
        voiceManager.speak(text, _selectedLanguage.value)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    // Sending Message & AI Generation
    fun sendMessage(userText: String) {
        if (userText.isBlank()) return

        val text = userText.trim()
        val convId = _currentConversationId.value

        // Append to UI list immediately
        val userMessage = ChatMessage(
            role = MessageRole.USER,
            text = text
        )
        _messages.value = _messages.value + userMessage
        _isAiThinking.value = true

        viewModelScope.launch {
            // Save user message to Room database
            try {
                repository.saveMessage(convId, MessageRole.USER, text)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save user message", e)
            }

            // Call Gemini
            val result = geminiService.generateChatResponse(text, _messages.value)
            _isAiThinking.value = false

            val assistantText = result.getOrElse { "उत्तर प्राप्त करने में समस्या हुई। कृपया पुनः प्रयास करें।" }

            val assistantMessage = ChatMessage(
                role = MessageRole.ASSISTANT,
                text = assistantText,
                quickActions = generateSmartQuickActions(text)
            )

            _messages.value = _messages.value + assistantMessage

            // Save assistant message to Room database
            try {
                repository.saveMessage(convId, MessageRole.ASSISTANT, assistantText)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save assistant message", e)
            }

            // Automatically speak if enabled
            if (_isAutoSpeakEnabled.value) {
                voiceManager.speak(assistantText, _selectedLanguage.value)
            }
        }
    }

    private fun generateSmartQuickActions(query: String): List<String> {
        val lower = query.lowercase()
        return when {
            lower.contains("छुट्टी") || lower.contains("पत्र") -> listOf("यह पत्र मुझे कॉपी करना है", "इसमें 2 दिन और जोड़ें", "अंग्रेजी में अनुवाद करें")
            lower.contains("मौसम") -> listOf("कल का मौसम कैसा रहेगा?", "क्या बारिश होगी?", "आज के लिए सुझाव")
            lower.contains("दस्तावेज") || lower.contains("बिल") -> listOf("दस्तावेज़ की फोटो अपलोड करें", "नियम समझाएं", "अंतिम तारीख क्या है?")
            else -> listOf("इसके बारे में और बताएं", "सरल शब्दों में समझाएं", "इसे सहेजें")
        }
    }

    // Start a Fresh New Conversation
    fun startNewConversation() {
        val newId = UUID.randomUUID().toString()
        _currentConversationId.value = newId
        _messages.value = listOf(
            ChatMessage(
                role = MessageRole.ASSISTANT,
                text = "नई बातचीत शुरू हो गई है। आप क्या पूछना या लिखवाना चाहते हैं?",
                quickActions = listOf("छुट्टी का आवेदन", "दस्तावेज़ समझना", "अनुवाद करना")
            )
        )
        voiceManager.stopSpeaking()
    }

    // Resume an Existing Conversation from Room
    fun loadConversation(conversation: ConversationEntity) {
        viewModelScope.launch {
            _currentConversationId.value = conversation.id
            val stored = repository.getMessagesForConversation(conversation.id)
            if (stored.isNotEmpty()) {
                _messages.value = stored
            } else {
                _messages.value = listOf(
                    ChatMessage(
                        role = MessageRole.ASSISTANT,
                        text = "बातचीत पुनः आरंभ की गई: \"${conversation.title}\""
                    )
                )
            }
            _currentTab.value = MainTab.ASSISTANT
            _userFeedbackMessage.value = "बातचीत लोड हो गई: ${conversation.title}"
        }
    }

    // Delete a Conversation from Room
    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            repository.deleteConversation(conversationId)
            if (_currentConversationId.value == conversationId) {
                startNewConversation()
            }
            _userFeedbackMessage.value = "बातचीत हटा दी गई"
        }
    }

    // Clear All History from Room
    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
            startNewConversation()
            _userFeedbackMessage.value = "सभी पिछली बातचीत हटा दी गई हैं"
        }
    }

    // Document Explainer Actions
    fun onDocumentImageSelected(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            try {
                val context = getApplication<Application>().applicationContext
                val inputStream = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()

                _selectedDocumentBitmap.value = bitmap
                _documentResult.value = null
                analyzeCurrentDocument()
            } catch (e: Exception) {
                Log.e(TAG, "Error reading image URI", e)
                _userFeedbackMessage.value = "चित्र लोड करने में समस्या हुई"
            }
        }
    }

    fun analyzeCurrentDocument(userQuestion: String = "") {
        val bitmap = _selectedDocumentBitmap.value ?: return
        _isAnalyzingDoc.value = true
        _documentResult.value = null

        viewModelScope.launch {
            val result = geminiService.analyzeDocument(bitmap, userQuestion)
            _isAnalyzingDoc.value = false
            result.onSuccess { docResult ->
                _documentResult.value = docResult
                if (_isAutoSpeakEnabled.value) {
                    val speechSnippet = "${docResult.title}। ${docResult.summaryHindi.take(150)}"
                    voiceManager.speak(speechSnippet, _selectedLanguage.value)
                }
            }.onFailure {
                _userFeedbackMessage.value = "दस्तावेज़ विश्लेषण में त्रुटि हुई"
            }
        }
    }

    fun clearDocument() {
        _selectedDocumentBitmap.value = null
        _documentResult.value = null
    }

    // Writing Assistant Actions
    fun selectWritingTemplate(template: WritingTemplate) {
        _selectedTemplate.value = template
        _writerCustomPrompt.value = template.defaultPrompt
        _generatedDraft.value = null
    }

    fun setWriterCustomPrompt(prompt: String) {
        _writerCustomPrompt.value = prompt
    }

    fun generateWritingDraft() {
        val template = _selectedTemplate.value ?: return
        val prompt = _writerCustomPrompt.value
        if (prompt.isBlank()) return

        _isGeneratingDraft.value = true
        _generatedDraft.value = null

        viewModelScope.launch {
            val langCode = when (_selectedLanguage.value) {
                AppLanguage.HINDI -> "Hindi"
                AppLanguage.HINGLISH -> "Hinglish"
                AppLanguage.ENGLISH -> "English"
            }
            val result = geminiService.generateWritingDraft(template.category, prompt, langCode)
            _isGeneratingDraft.value = false
            result.onSuccess { draft ->
                _generatedDraft.value = draft
                _userFeedbackMessage.value = "प्रारूप (Draft) तैयार है!"
            }.onFailure {
                _userFeedbackMessage.value = "प्रारूप बनाने में समस्या हुई"
            }
        }
    }

    // Translator Actions
    fun setTranslatorInput(text: String) {
        _translatorInput.value = text
    }

    fun swapTranslationLanguages() {
        val temp = _sourceLang.value
        _sourceLang.value = _targetLang.value
        _targetLang.value = temp

        val tempText = _translatorInput.value
        _translatorInput.value = _translatorOutput.value
        _translatorOutput.value = tempText
    }

    fun translate() {
        val input = _translatorInput.value
        if (input.isBlank()) return

        _isTranslating.value = true
        _translatorOutput.value = ""

        viewModelScope.launch {
            val result = geminiService.translateText(input, _sourceLang.value, _targetLang.value)
            _isTranslating.value = false
            result.onSuccess { output ->
                _translatorOutput.value = output
                if (_isAutoSpeakEnabled.value) {
                    val targetAppLang = if (_targetLang.value == "Hindi") AppLanguage.HINDI else AppLanguage.ENGLISH
                    voiceManager.speak(output, targetAppLang)
                }
            }.onFailure {
                _userFeedbackMessage.value = "अनुवाद में त्रुटि हुई"
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
