package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Navy & Violet Palette
val NavyDark = Color(0xFF0A0F1D)
val NavyBackground = Color(0xFF0F172A)
val NavySurface = Color(0xFF1E293B)
val NavyCard = Color(0xFF192237)
val NavyCardElevated = Color(0xFF243048)

val VioletPrimary = Color(0xFF8B5CF6)
val VioletSecondary = Color(0xFF6366F1)
val VioletGradientStart = Color(0xFF7C3AED)
val VioletGradientEnd = Color(0xFF4F46E5)
val CyanAccent = Color(0xFF06B6D4)
val CyanGlow = Color(0xFF22D3EE)
val PurpleGlow = Color(0xFFA855F7)

// Text and accent colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)

// Gradients
val MicGlowBrush = Brush.linearGradient(
    colors = listOf(CyanGlow, VioletPrimary, PurpleGlow)
)

val CardGradientBrush = Brush.linearGradient(
    colors = listOf(Color(0xFF1E2235), Color(0xFF141926))
)

val HeroHeaderBrush = Brush.verticalGradient(
    colors = listOf(Color(0xFF1E1B4B), Color(0xFF0F172A))
)
