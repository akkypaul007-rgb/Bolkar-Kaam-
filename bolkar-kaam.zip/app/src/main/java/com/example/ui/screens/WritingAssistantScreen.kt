package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardElevated
import com.example.ui.theme.NavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPrimary

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun WritingAssistantScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedTemplate by viewModel.selectedTemplate.collectAsStateWithLifecycle()
    val customPrompt by viewModel.writerCustomPrompt.collectAsStateWithLifecycle()
    val generatedDraft by viewModel.generatedDraft.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGeneratingDraft.collectAsStateWithLifecycle()
    val isEasyMode by viewModel.isEasyMode.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            text = "लेखन सहायक (Writing Assistant)",
            color = TextPrimary,
            fontSize = if (isEasyMode) 22.sp else 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "बिना किसी झिझक के छुट्टी का आवेदन, बायोडाटा, औपचारिक पत्र या व्यापार संदेश तैयार करें।",
            color = TextSecondary,
            fontSize = if (isEasyMode) 16.sp else 13.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )

        // Template Categories
        Text(
            text = "प्रारूप चुनें (Select Template):",
            color = CyanAccent,
            fontSize = if (isEasyMode) 16.sp else 13.sp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            viewModel.writingTemplates.forEach { template ->
                val isSelected = selectedTemplate?.id == template.id
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectWritingTemplate(template) },
                    leadingIcon = {
                        val icon: ImageVector = when (template.iconName) {
                            "email" -> Icons.Default.Email
                            "person" -> Icons.Default.Person
                            "gavel" -> Icons.Default.Gavel
                            else -> Icons.Default.Store
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = {
                        Text(
                            text = template.titleHi,
                            fontSize = if (isEasyMode) 15.sp else 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = VioletPrimary,
                        selectedLabelColor = Color.White,
                        selectedLeadingIconColor = Color.White,
                        containerColor = NavyCard,
                        labelColor = TextSecondary,
                        iconColor = TextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = if (isSelected) CyanGlow else Color(0xFF334155)
                    ),
                    modifier = Modifier.testTag("template_chip_${template.id}")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Custom Prompt Details Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "आवश्यक विवरण या निर्देश लिखें/बोलें:",
                    color = TextPrimary,
                    fontSize = if (isEasyMode) 16.sp else 14.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = customPrompt,
                    onValueChange = { viewModel.setWriterCustomPrompt(it) },
                    placeholder = {
                        Text(
                            text = "जैसे: मुझे 3 दिन की शादी की छुट्टी का आवेदन चाहिए...",
                            color = TextMuted
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyanGlow,
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = NavyCardElevated,
                        unfocusedContainerColor = NavyCardElevated,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 3,
                    maxLines = 6,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("writer_prompt_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Sample Quick Prompts
                selectedTemplate?.let { tmpl ->
                    Text(
                        text = "त्वरित उदाहरण (Quick Examples):",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        tmpl.sampleInputs.forEach { sample ->
                            SuggestionChip(
                                onClick = { viewModel.setWriterCustomPrompt(sample) },
                                label = { Text(text = sample, fontSize = 12.sp, color = CyanAccent) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = NavyDark
                                ),
                                border = SuggestionChipDefaults.suggestionChipBorder(
                                    enabled = true,
                                    borderColor = Color(0xFF334155)
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.generateWritingDraft() },
                    enabled = !isGenerating && customPrompt.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = VioletPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_draft_btn")
                ) {
                    if (isGenerating) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("प्रारूप तैयार किया जा रहा है...")
                    } else {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "प्रारूप (Draft) तैयार करें",
                            fontSize = if (isEasyMode) 18.sp else 15.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Generated Draft Preview
        if (generatedDraft != null) {
            val draft = generatedDraft!!
            Card(
                colors = CardDefaults.cardColors(containerColor = NavyCardElevated),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyanGlow.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "तैयार प्रारूप (Generated Draft)",
                            color = CyanAccent,
                            fontSize = if (isEasyMode) 18.sp else 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Row {
                            // Audio TTS
                            IconButton(
                                onClick = { viewModel.speakText(draft) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(NavyDark)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "सुनें",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // Copy
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Bolkar Kaam Draft", draft)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(context, "प्रारूप कॉपी कर लिया गया", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(VioletPrimary)
                                    .testTag("copy_draft_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "कॉपी करें",
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            // Share
                            IconButton(
                                onClick = {
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, draft)
                                        type = "text/plain"
                                    }
                                    val shareIntent = Intent.createChooser(sendIntent, "प्रारूप साझा करें")
                                    context.startActivity(shareIntent)
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(NavyDark)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "शेयर करें",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(NavyDark)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = draft,
                            color = TextPrimary,
                            fontSize = if (isEasyMode) 16.sp else 14.sp,
                            lineHeight = if (isEasyMode) 24.sp else 21.sp
                        )
                    }
                }
            }
        }
    }
}
