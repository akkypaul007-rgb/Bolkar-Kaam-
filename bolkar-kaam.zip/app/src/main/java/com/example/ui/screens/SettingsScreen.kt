package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.data.model.AppLanguage
import com.example.ui.MainViewModel
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardElevated
import com.example.ui.theme.NavyDark
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletPrimary

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val isEasyMode by viewModel.isEasyMode.collectAsStateWithLifecycle()
    val isAutoSpeak by viewModel.isAutoSpeakEnabled.collectAsStateWithLifecycle()
    val selectedLang by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    val hasGeminiKey = try {
        BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"
    } catch (e: Exception) {
        false
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Header
        Text(
            text = "सेटिंग्स और प्राथमिकताएं (Settings)",
            color = TextPrimary,
            fontSize = if (isEasyMode) 22.sp else 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "अपनी सुविधा अनुसार आसान मोड और आवाज़ नियंत्रण सेट करें।",
            color = TextSecondary,
            fontSize = if (isEasyMode) 16.sp else 13.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        // Easy Mode Toggle Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = if (isEasyMode) 2.dp else 1.dp,
                    color = if (isEasyMode) CyanAccent else Color(0xFF334155),
                    shape = RoundedCornerShape(16.dp)
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NavyCardElevated)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccessibilityNew,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "आसान मोड (Easy Mode)",
                            color = TextPrimary,
                            fontSize = if (isEasyMode) 18.sp else 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "बुजुर्गों और नए उपयोगकर्ताओं के लिए बड़े बटन और बड़ा फ़ॉन्ट",
                            color = TextSecondary,
                            fontSize = if (isEasyMode) 14.sp else 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Switch(
                    checked = isEasyMode,
                    onCheckedChange = { viewModel.toggleEasyMode() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = VioletPrimary,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = NavyCardElevated
                    ),
                    modifier = Modifier.testTag("easy_mode_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Audio Auto-Speak Toggle Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NavyCardElevated)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = VioletPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "उत्तर बोलकर सुनाएं (Auto-Speak)",
                            color = TextPrimary,
                            fontSize = if (isEasyMode) 18.sp else 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "AI उत्तरों को स्वचालित रूप से आवाज़ में पढ़कर सुनाए",
                            color = TextSecondary,
                            fontSize = if (isEasyMode) 14.sp else 12.sp
                        )
                    }
                }

                Switch(
                    checked = isAutoSpeak,
                    onCheckedChange = { viewModel.toggleAutoSpeak() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = VioletPrimary,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = NavyCardElevated
                    ),
                    modifier = Modifier.testTag("auto_speak_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Privacy & Security Card
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.setPrivacyDialogVisible(true) }
                .testTag("privacy_settings_card")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NavyCardElevated)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "गोपनीयता और डेटा सुरक्षा",
                            color = TextPrimary,
                            fontSize = if (isEasyMode) 18.sp else 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "स्थानीय डेटा संग्रहण और अनुमतियों का विवरण देखें",
                            color = TextSecondary,
                            fontSize = if (isEasyMode) 14.sp else 12.sp
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = TextMuted
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Clear All History Setting
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyCard),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.clearAllHistory() }
                .testTag("clear_history_settings_card")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(NavyCardElevated)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = null,
                        tint = Color(0xFFF87171),
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "सभी बातचीत का इतिहास हटाएं",
                        color = Color(0xFFF87171),
                        fontSize = if (isEasyMode) 18.sp else 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "फ़ोन पर सहेजा गया इतिहास तुरंत साफ़ करें",
                        color = TextSecondary,
                        fontSize = if (isEasyMode) 14.sp else 12.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // AI Engine Status
        Card(
            colors = CardDefaults.cardColors(containerColor = NavyDark),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.VpnKey,
                    contentDescription = null,
                    tint = if (hasGeminiKey) SuccessGreen else CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (hasGeminiKey) "Gemini Cloud AI सक्रिय है" else "बोलकर काम हाइब्रिड AI सक्रिय है",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (hasGeminiKey) "लाइव मॉडल द्वारा संचालित" else "ऑफलाइन टेम्पलेट्स व स्थानीय सहायक सक्रिय हैं",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // About Bolkar Kaam
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "बोलकर काम (Bolkar Kaam)",
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "आपकी आवाज़, आपका डिजिटल सहायक",
                color = CyanAccent,
                fontSize = 13.sp
            )
            Text(
                text = "संस्करण 1.0.0 • सुरक्षित व सुगम भारतीय आवाज़ सहायक",
                color = TextMuted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
