package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.PurpleGlow
import com.example.ui.theme.VioletPrimary

@Composable
fun GlowingMicButton(
    isListening: Boolean,
    isThinking: Boolean,
    rmsVolume: Float,
    isEasyMode: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_glow")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isListening) 1.25f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isListening) 800 else 2400,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = if (isListening) 0.8f else 0.3f,
        targetValue = 0.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isListening) 800 else 2400,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val baseSize: Dp = if (isEasyMode) 88.dp else 72.dp
    val dynamicScale = if (isListening) {
        (1f + rmsVolume * 0.35f).coerceIn(1f, 1.4f)
    } else {
        1f
    }

    val glowGradient = if (isListening) {
        listOf(CyanGlow, VioletPrimary, PurpleGlow)
    } else {
        listOf(VioletPrimary, Color(0xFF4F46E5), Color(0xFF312E81))
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(baseSize * 1.5f)
            .testTag("glowing_mic_container")
    ) {
        // Outer animated glow rings
        Box(
            modifier = Modifier
                .size(baseSize * 1.4f)
                .scale(pulseScale * dynamicScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            if (isListening) CyanAccent.copy(alpha = pulseAlpha) else VioletPrimary.copy(alpha = pulseAlpha),
                            Color.Transparent
                        )
                    )
                )
        )

        // Middle ring
        Box(
            modifier = Modifier
                .size(baseSize * 1.15f)
                .clip(CircleShape)
                .border(
                    width = if (isListening) 2.5.dp else 1.5.dp,
                    brush = Brush.sweepGradient(glowGradient),
                    shape = CircleShape
                )
        )

        // Main center button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(baseSize)
                .shadow(
                    elevation = if (isListening) 16.dp else 8.dp,
                    shape = CircleShape,
                    spotColor = if (isListening) CyanGlow else VioletPrimary,
                    ambientColor = PurpleGlow
                )
                .clip(CircleShape)
                .background(Brush.linearGradient(glowGradient))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    role = Role.Button,
                    onClick = onClick
                )
                .testTag("mic_toggle_button")
        ) {
            Icon(
                imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                contentDescription = if (isListening) "आवाज़ सुनना बंद करें (Stop Listening)" else "बोलना शुरू करें (Tap to Speak)",
                tint = Color.White,
                modifier = Modifier.size(if (isEasyMode) 42.dp else 34.dp)
            )
        }
    }
}
