package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.KeyboardVoice
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.data.model.SpeechState
import com.example.ui.MainViewModel
import com.example.ui.components.AudioWaveformVisualizer
import com.example.ui.components.GlowingMicButton
import com.example.ui.components.MessageBubble
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.CyanGlow
import com.example.ui.theme.NavyBackground
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyCardElevated
import com.example.ui.theme.NavyDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.VioletGradientEnd
import com.example.ui.theme.VioletGradientStart
import com.example.ui.theme.VioletPrimary

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun VoiceAssistantScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isThinking by viewModel.isAiThinking.collectAsStateWithLifecycle()
    val speechState by viewModel.speechState.collectAsStateWithLifecycle()
    val isSpeakingAudio by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val rmsVolume by viewModel.rmsVolume.collectAsStateWithLifecycle()
    val isEasyMode by viewModel.isEasyMode.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()

    var textInput by remember { mutableStateOf("") }
    var showKeyboardInput by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    // Scroll to latest message
    LaunchedEffect(messages.size, isThinking) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    // Audio Permission Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startVoiceInput()
        }
    }

    // Live recognized speech text
    LaunchedEffect(speechState) {
        if (speechState is SpeechState.Recognized) {
            val text = (speechState as SpeechState.Recognized).text
            if (text.isNotBlank()) {
                viewModel.sendMessage(text)
                viewModel.stopVoiceInput()
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NavyBackground)
    ) {
        // Top Sub-Bar: Language Selector & New Chat Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(NavyDark)
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Language selector chips
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AppLanguage.values().forEach { lang ->
                    FilterChip(
                        selected = selectedLanguage == lang,
                        onClick = { viewModel.setLanguage(lang) },
                        label = {
                            Text(
                                text = lang.displayName,
                                fontSize = if (isEasyMode) 14.sp else 12.sp,
                                fontWeight = if (selectedLanguage == lang) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VioletPrimary,
                            selectedLabelColor = Color.White,
                            containerColor = NavyCard,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedLanguage == lang,
                            borderColor = if (selectedLanguage == lang) CyanGlow else Color.Transparent
                        ),
                        modifier = Modifier.testTag("lang_chip_${lang.code}")
                    )
                }
            }

            // New Conversation Action
            IconButton(
                onClick = { viewModel.startNewConversation() },
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(NavyCardElevated)
                    .testTag("new_chat_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "नई बातचीत (New Chat)",
                    tint = CyanAccent,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Messages List
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 8.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    MessageBubble(
                        message = message,
                        isSpeakingThis = isSpeakingAudio,
                        isEasyMode = isEasyMode,
                        onSpeakClick = { text ->
                            if (isSpeakingAudio) {
                                viewModel.stopSpeaking()
                            } else {
                                viewModel.speakText(text)
                            }
                        },
                        onQuickActionClick = { actionText ->
                            viewModel.sendMessage(actionText)
                        }
                    )
                }

                // AI Thinking indicator
                if (isThinking) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .padding(vertical = 8.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NavyCard)
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = CyanGlow
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "बोलकर काम AI सोच रहा है...",
                                color = TextSecondary,
                                fontSize = if (isEasyMode) 16.sp else 13.sp
                            )
                        }
                    }
                }
            }
        }

        // Live Speech Feedback Banner
        AnimatedVisibility(
            visible = speechState is SpeechState.Listening || speechState is SpeechState.Error,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyDark)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                when (speechState) {
                    is SpeechState.Listening -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            AudioWaveformVisualizer(isActive = true)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "आपकी आवाज़ सुन रहा हूँ... बोलिए",
                                color = CyanAccent,
                                fontSize = if (isEasyMode) 18.sp else 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    is SpeechState.Error -> {
                        Text(
                            text = (speechState as SpeechState.Error).message,
                            color = Color(0xFFFCA5A5),
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                    else -> {}
                }
            }
        }

        // Center Voice Controller & Input Bar
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, NavyDark, NavyDark)
                    )
                )
                .padding(bottom = 12.dp, start = 12.dp, end = 12.dp)
        ) {
            // Optional Keyboard Text Field Fallback
            if (showKeyboardInput) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = {
                            Text(
                                text = "यहाँ संदेश टाइप करें...",
                                color = TextMuted,
                                fontSize = if (isEasyMode) 16.sp else 14.sp
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanGlow,
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedContainerColor = NavyCard,
                            unfocusedContainerColor = NavyCard,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("text_input_field")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            if (textInput.isNotBlank()) {
                                viewModel.sendMessage(textInput)
                                textInput = ""
                            }
                        },
                        enabled = textInput.isNotBlank(),
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (textInput.isNotBlank()) VioletPrimary else NavyCardElevated
                            )
                            .testTag("send_text_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "भेजें",
                            tint = if (textInput.isNotBlank()) Color.White else TextMuted
                        )
                    }
                }
            }

            // Microphone Section with Toggle Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                // Keyboard Fallback Toggle Button
                IconButton(
                    onClick = { showKeyboardInput = !showKeyboardInput },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(NavyCard)
                        .testTag("keyboard_toggle_button")
                ) {
                    Icon(
                        imageVector = if (showKeyboardInput) Icons.Default.KeyboardVoice else Icons.Default.Keyboard,
                        contentDescription = if (showKeyboardInput) "माइक्रोफ़ोन मोड" else "कीबोर्ड मोड",
                        tint = if (showKeyboardInput) CyanAccent else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Glowing Central Mic Button
                GlowingMicButton(
                    isListening = speechState is SpeechState.Listening,
                    isThinking = isThinking,
                    rmsVolume = rmsVolume,
                    isEasyMode = isEasyMode,
                    onClick = {
                        if (speechState is SpeechState.Listening) {
                            viewModel.stopVoiceInput()
                        } else {
                            val permissionCheck = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            )
                            if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                                viewModel.startVoiceInput()
                            } else {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    }
                )

                // TTS Speaker Toggle / Status
                IconButton(
                    onClick = {
                        if (isSpeakingAudio) {
                            viewModel.stopSpeaking()
                        } else {
                            viewModel.toggleAutoSpeak()
                        }
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(if (isSpeakingAudio) VioletPrimary else NavyCard)
                        .testTag("tts_status_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "आवाज़ में सुनें (Listen Out Loud)",
                        tint = if (isSpeakingAudio) Color.White else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // Tagline or helper text below mic
            Text(
                text = if (speechState is SpeechState.Listening) {
                    "सुन रहा हूँ... बोलना समाप्त होने पर रुकें"
                } else if (isEasyMode) {
                    "बोलने के लिए माइक बटन दबाएं"
                } else {
                    "आपकी आवाज़, आपका डिजिटल सहायक • बोलकर काम करें"
                },
                color = if (speechState is SpeechState.Listening) CyanAccent else TextMuted,
                fontSize = if (isEasyMode) 15.sp else 12.sp,
                fontWeight = if (speechState is SpeechState.Listening) FontWeight.Medium else FontWeight.Normal,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
