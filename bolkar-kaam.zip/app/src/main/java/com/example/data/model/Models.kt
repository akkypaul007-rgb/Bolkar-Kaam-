package com.example.data.model

import java.util.UUID

enum class MessageRole {
    USER,
    ASSISTANT
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val quickActions: List<String> = emptyList()
)

data class DocumentAnalysisResult(
    val title: String,
    val summaryHindi: String,
    val keyPoints: List<String>,
    val actionItems: List<String>,
    val disclaimer: String = "यह विश्लेषण केवल जानकारी के लिए है। किसी भी कानूनी, वित्तीय या चिकित्सीय निर्णय के लिए संबंधित प्रमाणित विशेषज्ञ से संपर्क करें।"
)

data class WritingTemplate(
    val id: String,
    val titleHi: String,
    val titleEn: String,
    val descriptionHi: String,
    val iconName: String,
    val category: String,
    val defaultPrompt: String,
    val sampleInputs: List<String>
)

enum class AppLanguage(val code: String, val displayName: String, val localeCode: String) {
    HINDI("hi", "हिंदी", "hi-IN"),
    HINGLISH("hinglish", "Hinglish (हिंग्लिश)", "hi-IN"),
    ENGLISH("en", "English", "en-IN")
}

sealed interface SpeechState {
    data object Idle : SpeechState
    data object Initializing : SpeechState
    data object Listening : SpeechState
    data class Recognized(val text: String) : SpeechState
    data class Error(val message: String) : SpeechState
}
