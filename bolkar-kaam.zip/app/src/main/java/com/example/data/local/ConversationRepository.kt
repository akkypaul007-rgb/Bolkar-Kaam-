package com.example.data.local

import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

class ConversationRepository(private val dao: ConversationDao) {

    val allConversations: Flow<List<ConversationEntity>> = dao.getAllConversations()

    suspend fun createConversation(firstMessageText: String): String = withContext(Dispatchers.IO) {
        val id = UUID.randomUUID().toString()
        val title = if (firstMessageText.length > 36) {
            firstMessageText.take(36) + "..."
        } else {
            firstMessageText
        }
        val conversation = ConversationEntity(
            id = id,
            title = title,
            previewText = firstMessageText,
            timestamp = System.currentTimeMillis(),
            messageCount = 0
        )
        dao.insertConversation(conversation)
        id
    }

    suspend fun saveMessage(
        conversationId: String,
        role: MessageRole,
        text: String
    ): ChatMessage = withContext(Dispatchers.IO) {
        // Ensure conversation exists
        val existing = dao.getConversationById(conversationId)
        if (existing == null) {
            val title = if (text.length > 36) text.take(36) + "..." else text
            dao.insertConversation(
                ConversationEntity(
                    id = conversationId,
                    title = title,
                    previewText = text,
                    timestamp = System.currentTimeMillis(),
                    messageCount = 1
                )
            )
        } else {
            dao.updateConversationPreview(conversationId, text, System.currentTimeMillis())
        }

        val messageEntity = MessageEntity(
            conversationId = conversationId,
            role = role.name,
            text = text,
            timestamp = System.currentTimeMillis()
        )
        dao.insertMessage(messageEntity)

        ChatMessage(
            id = messageEntity.id,
            role = role,
            text = text,
            timestamp = messageEntity.timestamp
        )
    }

    suspend fun getMessagesForConversation(conversationId: String): List<ChatMessage> = withContext(Dispatchers.IO) {
        val entities = dao.getMessagesListForConversation(conversationId)
        entities.map { entity ->
            ChatMessage(
                id = entity.id,
                role = if (entity.role == MessageRole.USER.name) MessageRole.USER else MessageRole.ASSISTANT,
                text = entity.text,
                timestamp = entity.timestamp
            )
        }
    }

    suspend fun deleteConversation(conversationId: String) = withContext(Dispatchers.IO) {
        dao.deleteMessagesForConversation(conversationId)
        dao.deleteConversation(conversationId)
    }

    suspend fun clearAllHistory() = withContext(Dispatchers.IO) {
        dao.clearAllMessages()
        dao.clearAllConversations()
    }
}
