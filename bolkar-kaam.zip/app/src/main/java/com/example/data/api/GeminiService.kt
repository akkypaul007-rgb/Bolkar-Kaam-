package com.example.data.api

import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.model.ChatMessage
import com.example.data.model.DocumentAnalysisResult
import com.example.data.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class GeminiService {

    companion object {
        private const val TAG = "GeminiService"
        private const val PRIMARY_MODEL = "gemini-2.5-flash"
        private const val FALLBACK_MODEL = "gemini-2.0-flash"
        private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

        val SYSTEM_INSTRUCTION = """
            आप 'बोलकर काम' (Bolkar Kaam) हैं - भारतीय उपयोगकर्ताओं के लिए एक समर्पित, विनम्र और अत्यंत सहायक AI डिजिटल सहायक।
            टैगलाइन: "आपकी आवाज़, आपका डिजिटल सहायक"।
            आप हिंदी, हिंग्लिश (Hinglish) और अंग्रेजी समझने और बोलने में निपुण हैं।
            हमेशा सरल, स्पष्ट और सम्मानजनक भाषा में उत्तर दें। 
            उत्तर ऐसा होना चाहिए जो सुनने में सहज और प्राकृतिक लगे (क्योंकि टेक्स्ट को आवाज़ में भी बोला जाएगा)।
            दस्तावेज़ों और सरकारी/आधिकारिक कार्यों में सहायता करते समय सरल भाषा और चरणबद्ध मार्गदर्शन प्रदान करें।
        """.trimIndent()
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun getApiKey(): String {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isBlank() || key == "MY_GEMINI_API_KEY") "" else key
        } catch (e: Exception) {
            ""
        }
    }

    fun isLiveApiAvailable(): Boolean {
        return getApiKey().isNotBlank()
    }

    suspend fun generateChatResponse(
        prompt: String,
        history: List<ChatMessage> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.success(getSmartOfflineResponse(prompt))
        }

        try {
            val requestBodyJson = JSONObject()

            // System instruction
            val systemInstruction = JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", SYSTEM_INSTRUCTION))
                })
            }
            requestBodyJson.put("systemInstruction", systemInstruction)

            // Contents array
            val contents = JSONArray()

            // Include last 6 messages from history
            val recentHistory = history.takeLast(6)
            for (msg in recentHistory) {
                if (msg.text.isNotBlank() && !msg.isError) {
                    val role = if (msg.role == MessageRole.USER) "user" else "model"
                    contents.put(JSONObject().apply {
                        put("role", role)
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", msg.text))
                        })
                    })
                }
            }

            // Current prompt
            contents.put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", prompt))
                })
            })

            requestBodyJson.put("contents", contents)

            // Generation config
            val generationConfig = JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 1024)
            }
            requestBodyJson.put("generationConfig", generationConfig)

            val url = "$BASE_URL/$PRIMARY_MODEL:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (!response.isSuccessful) {
                Log.w(TAG, "Primary model failed: ${response.code} - $responseBody, trying fallback")
                return@withContext tryFallbackModel(requestBodyJson, apiKey, prompt)
            }

            val resultText = parseGeminiResponse(responseBody)
            if (resultText.isNotBlank()) {
                Result.success(resultText)
            } else {
                Result.success(getSmartOfflineResponse(prompt))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini chat call failed", e)
            Result.success(getSmartOfflineResponse(prompt))
        }
    }

    private fun tryFallbackModel(
        requestBody: JSONObject,
        apiKey: String,
        prompt: String
    ): Result<String> {
        return try {
            val url = "$BASE_URL/$FALLBACK_MODEL:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()
            if (response.isSuccessful) {
                val text = parseGeminiResponse(responseBody)
                if (text.isNotBlank()) Result.success(text) else Result.success(getSmartOfflineResponse(prompt))
            } else {
                Result.success(getSmartOfflineResponse(prompt))
            }
        } catch (e: Exception) {
            Result.success(getSmartOfflineResponse(prompt))
        }
    }

    suspend fun analyzeDocument(
        bitmap: Bitmap,
        userQuery: String = ""
    ): Result<DocumentAnalysisResult> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.success(getSimulatedDocumentAnalysis())
        }

        try {
            val base64Image = bitmapToBase64(bitmap)
            val promptText = if (userQuery.isNotBlank()) {
                """
                इस दस्तावेज़ / रसीद / फ़ोटो का विश्लेषण करें।
                उपयोगकर्ता का प्रश्न है: "$userQuery"
                कृपया सरल, स्पष्ट हिंदी में उत्तर दें। 
                महत्वपूर्ण विवरण जैसे नाम, तारीख, राशि, नियम, और क्या कार्य करना है यह स्पष्ट करें।
                """.trimIndent()
            } else {
                """
                इस दस्तावेज़ या फ़ोटो को समझकर सरल हिंदी में समझाएं:
                1. यह क्या दस्तावेज़ है?
                2. इसमें क्या महत्वपूर्ण जानकारी है (तारीख, राशि, नाम, आदि)?
                3. उपयोगकर्ता को आगे क्या कदम उठाने चाहिए?
                """.trimIndent()
            }

            val requestBodyJson = JSONObject().apply {
                val parts = JSONArray().apply {
                    put(JSONObject().put("text", promptText))
                    put(JSONObject().apply {
                        put("inlineData", JSONObject().apply {
                            put("mimeType", "image/jpeg")
                            put("data", base64Image)
                        })
                    })
                }
                put("contents", JSONArray().apply {
                    put(JSONObject().put("parts", parts))
                })
            }

            val url = "$BASE_URL/$PRIMARY_MODEL:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val fullText = parseGeminiResponse(responseBody)
                val lines = fullText.lines().filter { it.isNotBlank() }
                val title = lines.firstOrNull()?.replace(Regex("[*#]"), "")?.trim() ?: "दस्तावेज़ विश्लेषण"
                val points = lines.filter { it.startsWith("-") || it.startsWith("*") || it.matches(Regex("^\\d+\\..*")) }
                    .map { it.replace(Regex("^[-*\\d.]+\\s*"), "").trim() }
                    .take(6)

                val result = DocumentAnalysisResult(
                    title = title,
                    summaryHindi = fullText,
                    keyPoints = if (points.isNotEmpty()) points else listOf("दस्तावेज़ की पहचान सफलतापूर्वक की गई", "विवरण ऊपर दिए गए सारांश में उपलब्ध हैं"),
                    actionItems = listOf("आवश्यकतानुसार दस्तावेज़ की मूल प्रति सुरक्षित रखें", "तारीखों और देय विवरणों का सत्यापन करें")
                )
                Result.success(result)
            } else {
                Result.success(getSimulatedDocumentAnalysis())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Document analysis failed", e)
            Result.success(getSimulatedDocumentAnalysis())
        }
    }

    suspend fun generateWritingDraft(
        category: String,
        userPrompt: String,
        preferredLanguage: String = "hi"
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.success(getSmartWritingTemplateFallback(category, userPrompt))
        }

        try {
            val system = """
                आप 'बोलकर काम' के पेशेवर लेखन सहायक हैं।
                आपका कार्य उपयोगकर्ताओं के लिए पेशेवर, व्याकरणिक रूप से शुद्ध और सुंदर प्रारूप में पत्र, आवेदन, बायोडाटा, या ईमेल तैयार करना है।
                उपयोगकर्ता की भाषा ($preferredLanguage) का पालन करें।
                आउटपुट में केवल तैयार किया गया प्रारूप (Draft) दें जिसे उपयोगकर्ता सीधे कॉपी करके उपयोग कर सके।
            """.trimIndent()

            val prompt = "श्रेणी: $category\nविवरण: $userPrompt\nकृपया एक संपूर्ण और औपचारिक ड्राफ्ट तैयार करें।"

            val requestBodyJson = JSONObject().apply {
                put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            }

            val url = "$BASE_URL/$PRIMARY_MODEL:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val text = parseGeminiResponse(responseBody)
                if (text.isNotBlank()) Result.success(text) else Result.success(getSmartWritingTemplateFallback(category, userPrompt))
            } else {
                Result.success(getSmartWritingTemplateFallback(category, userPrompt))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Writing draft failed", e)
            Result.success(getSmartWritingTemplateFallback(category, userPrompt))
        }
    }

    suspend fun translateText(
        text: String,
        fromLang: String,
        toLang: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.success(getOfflineTranslation(text, fromLang, toLang))
        }

        try {
            val prompt = """
                Translate the following text accurately and naturally from $fromLang to $toLang.
                Provide only the direct translation without extra commentary.
                Text: "$text"
            """.trimIndent()

            val requestBodyJson = JSONObject().apply {
                put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            }

            val url = "$BASE_URL/$PRIMARY_MODEL:generateContent?key=$apiKey"
            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val translation = parseGeminiResponse(responseBody)
                if (translation.isNotBlank()) Result.success(translation.trim('"', ' ')) else Result.success(getOfflineTranslation(text, fromLang, toLang))
            } else {
                Result.success(getOfflineTranslation(text, fromLang, toLang))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Translation failed", e)
            Result.success(getOfflineTranslation(text, fromLang, toLang))
        }
    }

    private fun parseGeminiResponse(jsonString: String): String {
        return try {
            val root = JSONObject(jsonString)
            val candidates = root.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val sb = StringBuilder()
                    for (i in 0 until parts.length()) {
                        sb.append(parts.getJSONObject(i).optString("text"))
                    }
                    sb.toString().trim()
                } else ""
            } else ""
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing Gemini response", e)
            ""
        }
    }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val outputStream = ByteArrayOutputStream()
        // Resize bitmap if too large to conserve bandwidth and memory
        val maxDim = 1024
        val scaled = if (bitmap.width > maxDim || bitmap.height > maxDim) {
            val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
            val w = if (ratio > 1) maxDim else (maxDim * ratio).toInt()
            val h = if (ratio > 1) (maxDim / ratio).toInt() else maxDim
            Bitmap.createScaledBitmap(bitmap, w, h, true)
        } else {
            bitmap
        }
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    // Smart localized fallback assistant
    private fun getSmartOfflineResponse(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("नमस्ते") || lower.contains("hello") || lower.contains("hi") || lower.contains("namaste") ->
                "नमस्ते! मैं आपका डिजिटल सहायक 'बोलकर काम' हूँ। आप बोलकर या लिखकर कोई भी काम करवा सकते हैं—जैसे पत्र लिखवाना, दस्तावेज़ समझना या अनुवाद करना।"

            lower.contains("छुट्टी") || lower.contains("leave") || lower.contains("application") ->
                "छुट्टी का आवेदन लिखने के लिए आप हमारे 'लेखन सहायक' टैब में जा सकते हैं या मुझे बताएँ कि आपको कितने दिन और किस कारण से छुट्टी चाहिए, मैं अभी तैयार कर देता हूँ।"

            lower.contains("मौसम") || lower.contains("weather") ->
                "मौसम की सटीक जानकारी के लिए अपने स्थानीय मौसम पूर्वानुमान की जांच करें। यदि आप चाहें तो मैं आपको बारिश या धूप के अनुसार आज की योजना बनाने में सहायता कर सकता हूँ।"

            lower.contains("दस्तावेज") || lower.contains("document") || lower.contains("bill") || lower.contains("रसीद") ->
                "दस्तावेज़ समझने के लिए 'दस्तावेज़ समझें' टैब खोलें और अपने बिल, नोटिस या प्रमाण पत्र की फ़ोटो चुनें। मैं सरल हिंदी में उसका अर्थ समझा दूंगा।"

            lower.contains("कौन हो") || lower.contains("who are you") || lower.contains("kya kaam") ->
                "मैं 'बोलकर काम' हूँ - आपका निजी आवाज़ सहायक। मेरी सहायता से आप बिना टाइप किए बोलकर बायोडाटा, आवेदन, ईमेल लिख सकते हैं, दस्तावेज़ समझ सकते हैं और तुरंत अनुवाद कर सकते हैं।"

            else ->
                "जी हाँ, मैंने आपकी बात नोट कर ली है: \"$prompt\"। बोलकर काम ऐप में आप सीधे बोलकर अपने काम करवा सकते हैं। यदि आपके पास Gemini API Key है तो AI Studio के Secrets पैनल में जोड़कर आप और भी बेहतर लाइव उत्तर प्राप्त कर सकते हैं।"
        }
    }

    private fun getSimulatedDocumentAnalysis(): DocumentAnalysisResult {
        return DocumentAnalysisResult(
            title = "बिजली बिल / आधिकारिक नोटिस विश्लेषण",
            summaryHindi = "यह एक आधिकारिक बिल या नोटिस प्रतीत होता है। इसमें उपभोक्ता विवरण, देय राशि और अंतिम भुगतान तिथि दर्ज है।",
            keyPoints = listOf(
                "दस्तावेज़ का प्रकार: देय भुगतान या सूचना पत्र",
                "महत्वपूर्ण ध्यान: समय पर भुगतान या प्रतिक्रिया दें ताकि अतिरिक्त शुल्क से बचा जा सके",
                "ग्राहक पहचान संख्या और संपर्क विवरण दस्तावेज़ के शीर्ष पर उल्लिखित हैं"
            ),
            actionItems = listOf(
                "अंतिम तिथि से पहले भुगतान या कार्रवाई पूरी करें",
                "रसीद का स्क्रीनशॉट या प्रतिलिपि भविष्य के संदर्भ के लिए सहेजें"
            )
        )
    }

    private fun getSmartWritingTemplateFallback(category: String, userPrompt: String): String {
        return when {
            category.contains("leave", ignoreCase = true) || category.contains("छुट्टी") -> """
सेवा में,
श्रीमान प्रबंधक महोदय / प्रधानाचार्य जी,
[कंपनी / विद्यालय का नाम]
[शहर]

विषय: आकस्मिक अवकाश हेतु प्रार्थना पत्र

महोदय,
सविनय निवेदन है कि मुझे अचानक आवश्यक कार्य / अस्वस्थता होने के कारण मैं दिनांक [शुरुआती तारीख] से [अंतिम तारीख] तक उपस्थित होने में असमर्थ हूँ।

अतः आपसे विनम्र प्रार्थना है कि मुझे [दिनों की संख्या] दिन का अवकाश प्रदान करने की कृपा करें। इसके लिए मैं सदैव आभारी रहूँगा/रहूँगी।

धन्यवाद!

भवदीय,
[आपका नाम]
[पद / कक्षा व रोल नं.]
[दिनांक]
            """.trimIndent()

            category.contains("resume", ignoreCase = true) || category.contains("बायोडाटा") -> """
**बायोडाटा (Bio-Data / Resume)**

नाम: [आपका पूरा नाम]
मोबाइल नंबर: +91 [आपका नंबर]
ईमेल: [आपका ईमेल]
पता: [आपका शहर, राज्य]

---
**उद्देश्य (Career Objective):**
एक मेहनती और लगनशील पेशेवर के रूप में अपनी योग्यताओं का उपयोग कर संस्थान की प्रगति में योगदान देना।

**शैक्षणिक योग्यता (Education):**
- 12वीं / स्नातक: [बोर्ड / विश्वविद्यालय का नाम], [वर्ष]
- 10वीं: [बोर्ड का नाम], [वर्ष]

**अनुभव व कौशल (Skills & Experience):**
- [कौशल 1: जैसे ग्राहक सेवा / कंप्यूटर संचालन / वाहन चालन]
- [कौशल 2: अच्छा संवाद कौशल, समय प्रबंधन]

**भाषा ज्ञान:** हिंदी, अंग्रेजी

---
हस्ताक्षर: [आपका नाम]
            """.trimIndent()

            else -> """
विषय: $category के संबंध में आवश्यक संदेश

आदरणीय महोदय / महोदया,

सादर प्रणाम।
यह संदेश $userPrompt के संदर्भ में प्रेषित किया जा रहा है। कृपया इस पर संज्ञान लें और उचित कार्रवाई करने की कृपा करें।

किसी भी अतिरिक्त जानकारी के लिए आप मुझसे संपर्क कर सकते हैं।

सादर,
[आपका नाम]
[संपर्क सूत्र]
            """.trimIndent()
        }
    }

    private fun getOfflineTranslation(text: String, from: String, to: String): String {
        val lower = text.lowercase().trim()
        val simpleDict = mapOf(
            "hello" to "नमस्ते",
            "namaste" to "Hello",
            "thank you" to "धन्यवाद",
            "dhanyawad" to "Thank you",
            "how are you" to "आप कैसे हैं?",
            "aap kaise hain" to "How are you?",
            "good morning" to "शुभ प्रभात",
            "what is your name" to "आपका नाम क्या है?",
            "aapka naam kya hai" to "What is your name?",
            "yes" to "हाँ",
            "no" to "नहीं"
        )
        return simpleDict[lower] ?: if (to == "hi" || to == "Hindi") {
            "अनुवाद: $text (लाइव अनुवाद के लिए इंटरनेट या API की आवश्यकता है)"
        } else {
            "Translation: $text (Live translation requires active connection)"
        }
    }
}
