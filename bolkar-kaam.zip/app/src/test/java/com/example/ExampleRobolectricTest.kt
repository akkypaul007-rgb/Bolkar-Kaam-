package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.ConversationRepository
import com.example.data.model.MessageRole
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: AppDatabase
    private lateinit var repository: ConversationRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = ConversationRepository(database.conversationDao())
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Bolkar Kaam", appName)
    }

    @Test
    fun `save and retrieve conversation in Room database`() = runBlocking {
        val convId = repository.createConversation("छुट्टी का आवेदन")
        val userMsg = repository.saveMessage(convId, MessageRole.USER, "मुझे 2 दिन की छुट्टी चाहिए")
        val assistantMsg = repository.saveMessage(convId, MessageRole.ASSISTANT, "यहाँ आपका आवेदन है...")

        val conversations = repository.allConversations.first()
        assertEquals(1, conversations.size)
        assertEquals("छुट्टी का आवेदन", conversations[0].title)

        val messages = repository.getMessagesForConversation(convId)
        assertEquals(2, messages.size)
        assertEquals(MessageRole.USER, messages[0].role)
        assertEquals(MessageRole.ASSISTANT, messages[1].role)
    }
}
